//
//  HudLayer.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "HudLayer.h"

@implementation HudLayer

-(id)init
{
    if ((self = [super init]))
    {
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"joypad.plist"];
        
        float radius = 64.0 * kPointFactor;
        _dPad = [ActionDPad dPadWithPrefix:@"dpad" radius:radius];
        _dPad.position = ccp(radius, radius);
        _dPad.opacity = 128;
        [self addChild:_dPad];
    }
    return self;
}

@end
