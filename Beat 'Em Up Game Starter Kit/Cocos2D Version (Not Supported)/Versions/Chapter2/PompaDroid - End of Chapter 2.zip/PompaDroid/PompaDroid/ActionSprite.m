//
//  ActionSprite.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "ActionSprite.h"

@implementation ActionSprite

-(void)idle
{
    if (_actionState != kActionStateIdle)
    {
        [self stopAllActions];
        [self runAction:_idleAction];
        _velocity = CGPointZero;
        self.actionState = kActionStateIdle;
    }
}

-(CCAnimation *)animationWithPrefix:(NSString *)prefix startFrameIdx:(NSUInteger)startFrameIdx frameCount:(NSUInteger)frameCount delay:(float)delay
{
    int idxCount = frameCount + startFrameIdx;
    CCArray *frames = [CCArray arrayWithCapacity:frameCount];
    int i;
    CCSpriteFrame *frame;
    for (i = startFrameIdx; i < idxCount; i++)
    {
        frame = [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"%@_%02d.png", prefix, i]];
        [frames addObject:frame];
    }
    
    return [CCAnimation animationWithSpriteFrames:[frames getNSArray] delay:delay];
}

-(void)walkWithDirection:(CGPoint)direction
{
    if (_actionState == kActionStateIdle || _actionState == kActionStateRun)
    {
        [self stopAllActions];
        [self runAction:_walkAction];
        self.actionState = kActionStateWalk;
        [self moveWithDirection:direction];
    }
    else if (_actionState == kActionStateWalk)
    {
        [self moveWithDirection:direction];
    }
}

-(void)moveWithDirection:(CGPoint)direction
{
    if (_actionState == kActionStateWalk)
    {
        _velocity = ccp(direction.x * _walkSpeed, direction.y * _walkSpeed);
        [self flipSpriteForVelocity:_velocity];
    }
    else if (_actionState == kActionStateRun)
    {
        _velocity = ccp(direction.x * _runSpeed, direction.y * _walkSpeed);
        [self flipSpriteForVelocity:_velocity];
    }
    else if (_actionState == kActionStateIdle)
    {
        [self walkWithDirection:direction];
    }
}

-(void)flipSpriteForVelocity:(CGPoint)velocity
{
    if (velocity.x > 0)
    {
        self.directionX = 1.0;
    }
    else if (velocity.x < 0)
    {
        self.directionX = -1.0;
    }
    
    self.scaleX = _directionX * kScaleFactor;
}

-(void)update:(ccTime)delta
{
    if (_actionState == kActionStateWalk)
    {
        _desiredPosition = ccpAdd(_position, ccpMult(_velocity, delta));
    }
}

-(CGRect)feetCollisionRect
{
    CGRect feetRect = CGRectMake(_desiredPosition.x -_centerToSides, _desiredPosition.y - _centerToBottom, _centerToSides * 2, 5.0 * kPointFactor);
    return CGRectInset(feetRect, 15.0 * kPointFactor, 0);
}

@end
