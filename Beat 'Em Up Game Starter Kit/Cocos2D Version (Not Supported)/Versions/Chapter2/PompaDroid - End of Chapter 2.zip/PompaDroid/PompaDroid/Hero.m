//
//  Hero.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "Hero.h"

@implementation Hero

-(id)init {
    if ((self = [super initWithSpriteFrameName:@"hero_idle_00.png"])) {
        //idle animation
        CCAnimation *idleAnimation = [self animationWithPrefix:@"hero_idle" startFrameIdx:0 frameCount:6 delay:1.0/12.0];
        self.idleAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:idleAnimation]];
        
        //walk animation
        CCAnimation *walkAnimation = [self animationWithPrefix:@"hero_walk" startFrameIdx:0 frameCount:8 delay:1.0/12.0];
        self.walkAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:walkAnimation]];
        
        self.walkSpeed = 80 * kPointFactor;
        self.directionX = 1.0;
        
        self.centerToBottom = 39.0 * kPointFactor;
        self.centerToSides = 29.0 * kPointFactor;

    }
    return self;
}



@end
