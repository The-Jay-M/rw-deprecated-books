//
//  GameLayer.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "GameLayer.h"

@implementation GameLayer

-(id)init
{
    if ((self = [super init]))
    {
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"sprites.plist"];
        _actors = [CCSpriteBatchNode batchNodeWithFile:@"sprites.pvr.ccz"];
        [_actors.texture setAliasTexParameters];
        [self addChild:_actors z:-5];
        [self initTileMap:@"map_level1.tmx"];
        [self initHero];
        [self scheduleUpdate];
    }
    return self;
}

-(void)initTileMap:(NSString *)fileName
{
    _tileMap = [CCTMXTiledMap tiledMapWithTMXFile:fileName];
    
    for (CCTMXLayer *child in [_tileMap children]) {
        [[child texture] setAliasTexParameters];
	}
    
    _tileMap.scale *= kScaleFactor;
    
    [self addChild:_tileMap z:-6];
}

-(void)initHero
{
    self.hero = [Hero node];
    [_actors addChild:_hero];
    _hero.scale *= kScaleFactor;
    _hero.position = ccp(100 * kPointFactor, 100 * kPointFactor);
    [_hero idle];
}

-(void)actionDPad:(ActionDPad *)actionDPad didChangeDirectionTo:(ActionDPadDirection)direction
{
    CGPoint directionVector = [self vectorForDirection:direction];
    [_hero walkWithDirection:directionVector];
}

-(void)actionDPad:(ActionDPad *)actionDPad isHoldingDirection:(ActionDPadDirection)direction
{
    CGPoint directionVector = [self vectorForDirection:direction];
    [_hero moveWithDirection:directionVector];
}

-(void)actionDPadTouchEnded:(ActionDPad *)actionDPad
{
    if (_hero.actionState == kActionStateWalk || _hero.actionState == kActionStateRun)
    {
        [_hero idle];
    }
}

-(CGPoint)vectorForDirection:(ActionDPadDirection)direction
{
    float maxX = 1.0;
    float maxY = 0.75;
    switch (direction) {
        case kActionDPadDirectionCenter:
            return CGPointZero;
            break;
        case kActionDPadDirectionUp:
            return ccp(0.0, maxY);
            break;
        case kActionDPadDirectionUpRight:
            return ccp(maxX, maxY);
            break;
        case kActionDPadDirectionRight:
            return ccp(maxX, 0.0);
            break;
        case kActionDPadDirectionDownRight:
            return ccp(maxX, -maxY);
            break;
        case kActionDPadDirectionDown:
            return ccp(0.0, -maxY);
            break;
        case kActionDPadDirectionDownLeft:
            return ccp(-maxX, -maxY);
            break;
        case kActionDPadDirectionLeft:
            return ccp(-maxX, 0.0);
            break;
        case kActionDPadDirectionUpLeft:
            return ccp(-maxX, maxY);
            break;
        default:
            return CGPointZero;
            break;
    }
}

-(void)dealloc
{
    [self unscheduleUpdate];
}

-(void)update:(ccTime)delta
{
    [_hero update:delta];
    [self updatePositions];
    [self setViewpointCenter:_hero.position];
}

-(void)updatePositions
{
    float mapWidth = _tileMap.mapSize.width * _tileMap.tileSize.width * kPointFactor;
    float floorHeight = 3 * _tileMap.tileSize.height * kPointFactor;
    float posX = MIN(mapWidth - _hero.feetCollisionRect.size.width/2, MAX(_hero.feetCollisionRect.size.width/2, _hero.desiredPosition.x));
    float posY = MIN(floorHeight + (_hero.centerToBottom - _hero.feetCollisionRect.size.height), MAX(_hero.centerToBottom, _hero.desiredPosition.y));
    _hero.position = ccp(posX, posY);
}

-(void)setViewpointCenter:(CGPoint) position {
    int x = MAX(position.x, CENTER.x);
    int y = MAX(position.y, CENTER.y);
    x = MIN(x, (_tileMap.mapSize.width * _tileMap.tileSize.width * kPointFactor)
            - CENTER.x);
    y = MIN(y, (_tileMap.mapSize.height * _tileMap.tileSize.height * kPointFactor)
            - CENTER.y);
    CGPoint actualPosition = ccp(x, y);

    CGPoint viewPoint = ccpSub(CENTER, actualPosition);
    self.position = viewPoint;
}

@end
