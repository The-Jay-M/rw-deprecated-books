//
//  GameLayer.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "GameLayer.h"
#import "Robot.h"
#import "ArtificialIntelligence.h"
#import "GameScene.h"

@implementation GameLayer

-(id)init
{
    if ((self = [super init]))
    {
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"sprites.plist"];
        _actors = [CCSpriteBatchNode batchNodeWithFile:@"sprites.pvr.ccz"];
        [_actors.texture setAliasTexParameters];
        [self addChild:_actors z:-5];
        [self loadLevel:0];
        [self initHero];
        [self initRobots];
        [self initBrains];
        [self scheduleUpdate];

    }
    return self;
}

-(void)loadLevel:(int)level
{
    NSString *levelsPlist = [[NSBundle mainBundle] pathForResource:@"Levels" ofType:@"plist"];
    NSMutableArray *levelArray = [[NSMutableArray alloc] initWithContentsOfFile:levelsPlist];
    NSDictionary *levelData = [[NSDictionary alloc] initWithDictionary:levelArray[level]];
    
    NSString *tileMap = [levelData objectForKey:@"TileMap"];
    [self initTileMap:tileMap];
    
    //store the events
    _battleEvents = [CCArray arrayWithNSArray:[levelData objectForKey:@"BattleEvents"]];
    _totalLevels = levelArray.count;
    _currentLevel = level;

}

-(void)initBrains
{
    self.brains = [[CCArray alloc] initWithCapacity:_robots.count];
    ArtificialIntelligence *brain;
    Robot *robot;

    CCARRAY_FOREACH(_robots, robot)
    {
        brain = [ArtificialIntelligence aiWithControlledSprite:robot targetSprite:_hero];
        [_brains addObject:brain];
    }
}

-(void)initRobots {
    int robotCount = 50;
    self.robots = [[CCArray alloc] initWithCapacity:robotCount];
    
    for (int i = 0; i < robotCount; i++) {
        Robot *robot = [Robot node];
        robot.delegate = self;
        [_actors addChild:robot.shadow];
        [_actors addChild:robot.smoke];
        [_actors addChild:robot];
        [_actors addChild:robot.belt];
        [_robots addObject:robot];
                
        robot.scale *= kScaleFactor;            //scaling simplified
        robot.shadow.scale *= kScaleFactor;
        robot.position = OFFSCREEN;             //this changed
        robot.groundPosition = robot.position;
        robot.desiredPosition = robot.position;
        robot.visible = NO;                     //added this line
                                                //this line was removed: [robot idle];
        robot.colorSet = kColorRandom;
    }
}

-(void)spawnEnemies:(CCArray *)enemies fromOrigin:(float)origin
{
    NSDictionary *enemyData;
    Robot *robot;
    
    int row, type, color;
    float offset;
    
    CCARRAY_FOREACH(enemies, enemyData)
    {
        row = [[enemyData objectForKey:@"Row"] floatValue];
        type = [[enemyData objectForKey:@"Type"] intValue];
        offset = [[enemyData objectForKey:@"Offset"] floatValue];
        
        if (type == kEnemyRobot)
        {
            color = [[enemyData objectForKey:@"Color"] intValue];
            
            //get an unused robot
            CCARRAY_FOREACH(_robots, robot)
            {
                if (robot.actionState == kActionStateNone)
                {
                    [robot stopAllActions];
                    robot.visible = NO;
                    robot.groundPosition = ccp(origin + (offset * (CENTER.x + robot.centerToSides)), robot.centerToBottom + _tileMap.tileSize.height * row * kPointFactor);
                    robot.position = robot.groundPosition;
                    robot.desiredPosition = robot.groundPosition;
                    [robot setColorSet:color];
                    [robot idle];
                    robot.visible = YES;
                    break;
                }
            }
        }
    }
}

-(void)initTileMap:(NSString *)fileName
{
    _tileMap = [CCTMXTiledMap tiledMapWithTMXFile:fileName];
    
    for (CCTMXLayer *child in [_tileMap children]) {
        [[child texture] setAliasTexParameters];
	}
    
    _tileMap.scale *= kScaleFactor;
    
    [self addChild:_tileMap z:-6];
}

-(void)initHero
{
    self.hero = [Hero node];
    _hero.delegate = self;
    [_actors addChild:_hero.shadow];
    _hero.shadow.scale *= kScaleFactor;
    [_actors addChild:_hero];
    _hero.scale *= kScaleFactor;
    //change _hero.position = ccp(100 * kPointFactor, 100 * kPointFactor) to
    _hero.position = ccp(-_hero.centerToSides, 80 * kPointFactor);
    //add the following two lines
    _hero.desiredPosition = _hero.position;
    _hero.groundPosition = _hero.position;
    //remove [_hero idle];
}

-(void)actionDPad:(ActionDPad *)actionDPad didChangeDirectionTo:(ActionDPadDirection)direction
{
    //enclose everything in this condition
    if (_eventState != kEventStateScripted)
    {
        CGPoint directionVector = [self vectorForDirection:direction];
        
        if (_runDelay > 0 && _previousDirection == direction && (direction == kActionDPadDirectionRight || direction == kActionDPadDirectionLeft))
        {
            [_hero runWithDirection:directionVector];
        }
        else if (_hero.actionState == kActionStateRun && abs(_previousDirection - direction) <= 1)
        {
            [_hero moveWithDirection:directionVector];
        }
        else
        {
            [_hero walkWithDirection:directionVector];
            _previousDirection = direction;
            _runDelay = 0.2;
        }
    }
}

-(void)actionDPad:(ActionDPad *)actionDPad isHoldingDirection:(ActionDPadDirection)direction
{
    CGPoint directionVector = [self vectorForDirection:direction];
    [_hero moveWithDirection:directionVector];
}

-(void)actionDPadTouchEnded:(ActionDPad *)actionDPad
{
    //modify the if condition as shown
    if (_eventState != kEventStateScripted && (_hero.actionState == kActionStateWalk || _hero.actionState == kActionStateRun))
    {
        [_hero idle];
    }
}

-(CGPoint)vectorForDirection:(ActionDPadDirection)direction
{
    float maxX = 1.0;
    float maxY = 0.75;
    switch (direction) {
        case kActionDPadDirectionCenter:
            return CGPointZero;
            break;
        case kActionDPadDirectionUp:
            return ccp(0.0, maxY);
            break;
        case kActionDPadDirectionUpRight:
            return ccp(maxX, maxY);
            break;
        case kActionDPadDirectionRight:
            return ccp(maxX, 0.0);
            break;
        case kActionDPadDirectionDownRight:
            return ccp(maxX, -maxY);
            break;
        case kActionDPadDirectionDown:
            return ccp(0.0, -maxY);
            break;
        case kActionDPadDirectionDownLeft:
            return ccp(-maxX, -maxY);
            break;
        case kActionDPadDirectionLeft:
            return ccp(-maxX, 0.0);
            break;
        case kActionDPadDirectionUpLeft:
            return ccp(-maxX, maxY);
            break;
        default:
            return CGPointZero;
            break;
    }
}

-(void)dealloc
{
    [self unscheduleUpdate];
}

-(NSInteger)getZFromYPosition:(float)yPosition
{
    return (_tileMap.mapSize.height * _tileMap.tileSize.height * kPointFactor) - yPosition;
}

-(void)reorderActors
{
    NSInteger spriteZ = [self getZFromYPosition:_hero.groundPosition.y];
    
    [_actors reorderChild:_hero.shadow z:spriteZ];
    [_actors reorderChild:_hero z:spriteZ];

    Robot *robot;
    CCARRAY_FOREACH(_robots, robot)
    {
        spriteZ = [self getZFromYPosition:robot.groundPosition.y];
        [_actors reorderChild:robot.shadow z:spriteZ];
        [_actors reorderChild:robot.smoke z:spriteZ];
        [_actors reorderChild:robot z:spriteZ];
        [_actors reorderChild:robot.belt z:spriteZ];
    }
}

-(void)update:(ccTime)delta
{
    [_hero update:delta];
    
    ArtificialIntelligence *brain;
    CCARRAY_FOREACH(_brains, brain)
    {
        [brain update:delta];
    }
    
    Robot *robot;
    CCARRAY_FOREACH(_robots, robot)
    {
        [robot update:delta];
    }

    [self updatePositions];
    [self reorderActors];
    
    if (_runDelay > 0)
    {
        _runDelay -= delta;
    }
    
    if (_eventState == kEventStateFreeWalk || _eventState == kEventStateScripted)
    {
        [self setViewpointCenter:_hero.position];
    }
    
    [self updateEvent];
    
    if (_viewPointOffset < 0)
    {
        _viewPointOffset += SCREEN.width * delta;
        
        if (_viewPointOffset >= 0)
        {
            _viewPointOffset = 0;
        }
    }
    else if (_viewPointOffset > 0)
    {
        _viewPointOffset -= SCREEN.width * delta;
        
        if (_viewPointOffset <= 0)
        {
            _viewPointOffset = 0;
        }
    }
    
}

-(void)updateEvent
{
    if (_eventState == kEventStateBattle && _activeEnemies <= 0)
    {
        float maxCenterX = _tileMap.mapSize.width * _tileMap.tileSize.width * kPointFactor - CENTER.x;
        float cameraX = MAX(MIN(_hero.position.x, maxCenterX), CENTER.x);
        _viewPointOffset = cameraX  - _eventCenter;
        _eventState = kEventStateFreeWalk;
    }
    else if (_eventState == kEventStateFreeWalk)
    {
        //add this
        if (_battleEvents.count == 0)
        {
            [self exitLevel];
        }
        else
        {
            [self cycleEvents];
        }
    }
    else if (_eventState == kEventStateScripted) //add this
    {
        float exitX = _tileMap.tileSize.width * _tileMap.mapSize.width * kPointFactor + _hero.centerToSides;
        if (_hero.position.x >= exitX)
        {
            _eventState = kEventStateEnd;
            if (_currentLevel < _totalLevels - 1)
            {
                //next level
                [[CCDirector sharedDirector] replaceScene:[CCTransitionFade transitionWithDuration:1.0 scene:[GameScene nodeWithLevel:_currentLevel + 1]]];
            }
            else
            {
                //end game
            }
        }
    }
}

-(void)exitLevel
{
    _eventState = kEventStateScripted;
    float exitX = _tileMap.tileSize.width * _tileMap.mapSize.width * kPointFactor + _hero.centerToSides;
    [_hero enterFrom:_hero.position to:ccp(exitX, _hero.position.y)];
}

-(void)cycleEvents
{
    NSDictionary *event;
    int column;
    float tileWidth = _tileMap.tileSize.width * kPointFactor;
    CCARRAY_FOREACH(_battleEvents, event)
    {
        column = [[event objectForKey:@"Column"] intValue];
        float maxCenterX = _tileMap.mapSize.width * _tileMap.tileSize.width * kPointFactor - CENTER.x;
        float columnPosition = column * tileWidth - tileWidth/2;
        _eventCenter = MAX(MIN(columnPosition, maxCenterX), CENTER.x);
        if (_hero.position.x >= _eventCenter) // 1
        {
            _currentEvent = event;
            _eventState = kEventStateBattle;
            CCArray *enemyData = [CCArray arrayWithNSArray:[event objectForKey:@"Enemies"]];
            _activeEnemies = enemyData.count;
            [self spawnEnemies:enemyData fromOrigin:_eventCenter];
            [self setViewpointCenter:ccp(_eventCenter, _hero.position.y)];
            break;
        }
    }
    
    if (_eventState == kEventStateBattle)
    {
        [_battleEvents removeObject:_currentEvent];
    }
}

-(void)onEnterTransitionDidFinish
{
    [super onEnterTransitionDidFinish];
    _eventState = kEventStateScripted;
    [_hero enterFrom:_hero.position to:ccp(64.0, _hero.position.y)];
    [self performSelector:@selector(triggerEvent:) withObject:[NSNumber numberWithInt:kEventStateFreeWalk] afterDelay:1.2];
}

-(void)triggerEvent:(NSNumber *)eventId
{
    self.eventState = [eventId intValue];
}

-(void)updatePositions
{
    float mapWidth = _tileMap.mapSize.width * _tileMap.tileSize.width * kPointFactor;
    float floorHeight = 3 * _tileMap.tileSize.height * kPointFactor;
    float posX, posY;
    
    if (_hero.actionState > kActionStateNone)
    {
        // 1
        if (_eventState == kEventStateFreeWalk)
        {
            posX = MIN(mapWidth - _hero.feetCollisionRect.size.width/2, MAX(_hero.feetCollisionRect.size.width/2, _hero.desiredPosition.x));
            posY = MIN(floorHeight + (_hero.centerToBottom - _hero.feetCollisionRect.size.height), MAX(_hero.centerToBottom, _hero.desiredPosition.y));
            
            _hero.groundPosition = ccp(posX, posY);
            _hero.position = ccp(_hero.groundPosition.x, _hero.groundPosition.y + _hero.jumpHeight);
        }
        else if (_eventState == kEventStateBattle)
        {
            posX = MIN(MIN(mapWidth - _hero.feetCollisionRect.size.width/2, _eventCenter + CENTER.x - _hero.feetCollisionRect.size.width/2), MAX(_eventCenter - CENTER.x + _hero.feetCollisionRect.size.width/2, _hero.desiredPosition.x));
            posY = MIN(floorHeight + (_hero.centerToBottom - _hero.feetCollisionRect.size.height), MAX(_hero.centerToBottom, _hero.desiredPosition.y));
            _hero.groundPosition = ccp(posX, posY);
            _hero.position = ccp(_hero.groundPosition.x, _hero.groundPosition.y + _hero.jumpHeight);
        }
    }
    
    Robot *robot;
    CCARRAY_FOREACH(_robots, robot)
    {
        if (robot.actionState > kActionStateNone)
        {            
            posY = MIN(floorHeight + (robot.centerToBottom - robot.feetCollisionRect.size.height), MAX(robot.centerToBottom, robot.desiredPosition.y));
            robot.groundPosition = ccp(robot.desiredPosition.x, posY);
            robot.position = ccp(robot.groundPosition.x, robot.groundPosition.y + robot.jumpHeight);
            
            if (robot.actionState == kActionStateDead && _hero.groundPosition.x - robot.groundPosition.x >= CENTER.x + robot.contentSize.width/2 * kScaleFactor)
            {
                robot.visible = NO;
                [robot reset];
            }
        }
    }
}

-(void)setViewpointCenter:(CGPoint) position {
    int x = MAX(position.x, CENTER.x);
    int y = MAX(position.y, CENTER.y);
    x = MIN(x, (_tileMap.mapSize.width * _tileMap.tileSize.width * kPointFactor)
            - CENTER.x);
    y = MIN(y, (_tileMap.mapSize.height * _tileMap.tileSize.height * kPointFactor)
            - CENTER.y);
    CGPoint actualPosition = ccp(x, y);

    CGPoint viewPoint = ccpSub(CENTER, actualPosition);
    self.position = ccp(viewPoint.x + _viewPointOffset, viewPoint.y);
}

-(void)actionButtonWasPressed:(ActionButton *)actionButton
{
    //enclose everything in this condition
    if (_eventState != kEventStateScripted)
    {
        if (actionButton.tag == kTagButtonA)
        {
            [_hero attack];
        }
        else if (actionButton.tag == kTagButtonB)
        {
            CGPoint directionVector = [self vectorForDirection:_hud.dPad.direction];
            [_hero jumpRiseWithDirection:directionVector];
        }
    }
}

-(void)actionButtonIsHeld:(ActionButton *)actionButton{
}

-(void)actionButtonWasReleased:(ActionButton *)actionButton
{
    if (actionButton.tag == kTagButtonB)
    {
        [_hero jumpCutoff];
    }
}

#if DRAW_DEBUG_SHAPES

-(void)draw
{
    [super draw];
    [self drawShapesForActionSprite:_hero];

    ActionSprite *actionSprite;
    CCARRAY_FOREACH(_robots, actionSprite)
    {
        [self drawShapesForActionSprite:actionSprite];
    }
}

-(void)drawShapesForActionSprite:(ActionSprite *)sprite
{
    if (sprite.visible)
    {
        int i;
        
        ccDrawColor4B(0, 0, 255, 255);
        ccDrawCircle(sprite.position, sprite.detectionRadius, 0, 16, NO);
        
        ccDrawColor4B(0, 255, 0, 255);
        for (i = 0; i < sprite.contactPointCount; i++)
        {
            ccDrawCircle(sprite.contactPoints[i].position, sprite.contactPoints[i].radius, 0, 8, NO);
        }
        
        ccDrawColor4B(255, 0, 0, 255);
        for (i = 0; i < sprite.attackPointCount; i++)
        {
            ccDrawCircle(sprite.attackPoints[i].position, sprite.attackPoints[i].radius, 0, 8, NO);
        }
        
        ccDrawColor4B(255, 255, 0, 255);
        ccDrawRect(sprite.feetCollisionRect.origin, ccp(sprite.feetCollisionRect.origin.x + sprite.feetCollisionRect.size.width, sprite.feetCollisionRect.origin.y + sprite.feetCollisionRect.size.height));
    }
}

#endif

//add these methods
-(BOOL)actionSpriteDidDie:(ActionSprite *)actionSprite
{
    if (actionSprite == _hero)
    {
        
    }
    else
    {
        _activeEnemies--;
        return YES;
    }
    
    return NO;
}

-(BOOL)actionSpriteDidAttack:(ActionSprite *)actionSprite
{
    // 1
    BOOL didHit = NO;
    if (actionSprite == _hero)
    {
        CGPoint attackPosition;
        Robot *robot;
        CCARRAY_FOREACH(_robots, robot)
        {
            // 2
            if (robot.actionState < kActionStateKnockedOut && robot.actionState != kActionStateNone)
            {            
                if ([self collisionBetweenAttacker:_hero andTarget:robot atPosition:&attackPosition])
                {
                    if (_hero.actionState == kActionStateJumpAttack)
                    {
                        [robot knockoutWithDamage:_hero.jumpAttackDamage direction:ccp(_hero.directionX, 0)];
                    }
                    else if (_hero.actionState == kActionStateRunAttack)
                    {
                        [robot knockoutWithDamage:_hero.runAttackDamage direction:ccp(_hero.directionX, 0)];
                    }
                    else if (_hero.actionState == kActionStateAttackThree)  //add this
                    {
                        [robot knockoutWithDamage:_hero.attackThreeDamage direction:ccp(_hero.directionX, 0)];
                    }
                    else if (_hero.actionState == kActionStateAttackTwo)    //add this
                    {
                        [robot hurtWithDamage:_hero.attackTwoDamage force:_hero.attackForce direction:ccp(_hero.directionX, 0.0)];
                    }
                    else
                    {
                        [robot hurtWithDamage:_hero.attackDamage force:_hero.attackForce direction:ccp(_hero.directionX, 0.0)];
                    }
                    didHit = YES;
                }
            }
        }
        return didHit;
    }
    // 3
    else
    {
        if (_hero.actionState < kActionStateKnockedOut && _hero.actionState != kActionStateNone)
        {
            CGPoint attackPosition;
            if ([self collisionBetweenAttacker:actionSprite andTarget:_hero atPosition:&attackPosition])
            {
                [_hero hurtWithDamage:actionSprite.attackDamage  force:actionSprite.attackForce direction:ccp(actionSprite.directionX, 0.0)];
                didHit = YES;
            }
        }
    }
    return didHit;
}


-(BOOL)collisionBetweenAttacker:(ActionSprite *)attacker andTarget:(ActionSprite *)target atPosition:(CGPoint *)position
{
    //first phase: check if they're on the same plane
    float planeDist = attacker.shadow.position.y - target.shadow.position.y;
    
    if (fabsf(planeDist) <= kPlaneHeight)
    {
        int i, j;
        float combinedRadius = attacker.detectionRadius + target.detectionRadius;
        
        //initial detection
        if (ccpDistanceSQ(attacker.position, target.position) <= combinedRadius * combinedRadius)
        {
            int attackPointCount = attacker.attackPointCount;
            int contactPointCount = target.contactPointCount;
            
            ContactPoint attackPoint, contactPoint;
            
            //secondary detection
            for (i = 0; i < attackPointCount; i++)
            {
                attackPoint = attacker.attackPoints[i];
                
                for (j = 0; j < contactPointCount; j++)
                {
                    contactPoint = target.contactPoints[j];
                    combinedRadius = attackPoint.radius + contactPoint.radius;
                    
                    if (ccpDistanceSQ(attackPoint.position, contactPoint.position) <= combinedRadius * combinedRadius)
                    {
                        //attack point collided with contact point
                        position->x = attackPoint.position.x;
                        position->y = attackPoint.position.y;
                        return YES;
                    }
                }
            }
        }
    }
    return NO;
}

+(id)nodeWithLevel:(int)level
{
    return [[self alloc] initWithLevel:level];
}

-(id)initWithLevel:(int)level
{
    if ((self = [super init]))
    {
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"sprites.plist"];
        _actors = [CCSpriteBatchNode batchNodeWithFile:@"sprites.pvr.ccz"];
        [_actors.texture setAliasTexParameters];
        [self addChild:_actors z:-5];
        [self loadLevel:level];
        [self initHero];
        [self initRobots];
        [self initBrains];
        [self scheduleUpdate];
    }
    return self;
}

@end
