//
//  Hero.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "Hero.h"

@implementation Hero

-(id)init {
    if ((self = [super initWithSpriteFrameName:@"hero_idle_00.png"])) {
        //idle animation
        CCAnimation *idleAnimation = [self animationWithPrefix:@"hero_idle" startFrameIdx:0 frameCount:6 delay:1.0/12.0];
        self.idleAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:idleAnimation]];
        
        //walk animation
        CCAnimation *walkAnimation = [self animationWithPrefix:@"hero_walk" startFrameIdx:0 frameCount:8 delay:1.0/12.0];
        self.walkAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:walkAnimation]];
        
        // run animation
        CCAnimation *runAnimation = [self animationWithPrefix:@"hero_run" startFrameIdx:0 frameCount:8 delay:1.0/12.0];
        self.runAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:runAnimation]];

        // attack animation
        CCAnimation *attackAnimation = [self animationWithPrefix:@"hero_attack_00" startFrameIdx:0 frameCount:3 delay:1.0/15.0];
        self.attackAction = [CCSequence actions:[CCAnimate actionWithAnimation:attackAnimation], [CCCallFunc actionWithTarget:self selector:@selector(idle)], nil];

        self.runSpeed = 160 * kPointFactor;
        self.walkSpeed = 80 * kPointFactor;
        self.directionX = 1.0;
        
        self.centerToBottom = 39.0 * kPointFactor;
        self.centerToSides = 29.0 * kPointFactor;
        
        self.shadow = [CCSprite spriteWithSpriteFrameName:@"shadow_character.png"];
        self.shadow.opacity = 190;

        CCArray *jumpRiseFrames = [CCArray arrayWithCapacity:2];
        [jumpRiseFrames addObject:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"hero_jump_05.png"]];
        [jumpRiseFrames addObject:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"hero_jump_00.png"]];
        self.jumpRiseAction = [CCAnimate actionWithAnimation:[CCAnimation animationWithSpriteFrames:[jumpRiseFrames getNSArray] delay:1.0/12.0]];

        self.jumpFallAction = [CCAnimate actionWithAnimation:[self animationWithPrefix:@"hero_jump" startFrameIdx:1 frameCount:4 delay:1.0/12.0]];

        self.jumpLandAction = [CCSequence actions:[CCCallFunc actionWithTarget:self selector:@selector(setLandingDisplayFrame)], [CCDelayTime actionWithDuration:1.0/12.0], [CCCallFunc actionWithTarget:self selector:@selector(idle)], nil];

    }
    return self;
}

-(void)setLandingDisplayFrame
{
    [self setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"hero_jump_05.png"]];
}

@end
