//
//  HudLayer.h
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ActionDPad.h"
#import "ActionButton.h"

@interface HudLayer : CCLayer {
    
}

@property(nonatomic, weak)ActionDPad *dPad;
@property(nonatomic, weak)ActionButton *buttonA;
@property(nonatomic, weak)ActionButton *buttonB;

@end
