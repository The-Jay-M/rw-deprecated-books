//
//  Robot.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/12/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "Robot.h"
#import "AnimateGroup.h"

@implementation Robot

-(id)init
{
    if ((self = [super initWithSpriteFrameName:@"robot_base_idle_00.png"]))
    {
        self.belt = [CCSprite spriteWithSpriteFrameName:@"robot_belt_idle_00.png"];
        self.smoke = [CCSprite spriteWithSpriteFrameName:@"robot_smoke_idle_00.png"];
        
        self.shadow = [CCSprite spriteWithSpriteFrameName:@"shadow_character.png"];
        self.shadow.opacity = 190;
        
        AnimateGroup *idleAnimationGroup = [self animateGroupWithActionWord:@"idle" frameCount:5 delay:1.0/12.0];
        self.idleAction = [CCRepeatForever actionWithAction:idleAnimationGroup];

        AnimateGroup *attackAnimationGroup = [self animateGroupWithActionWord:@"attack" frameCount:5 delay:1.0/15.0];
        self.attackAction = [CCSequence actions:attackAnimationGroup, [CCCallFunc actionWithTarget:self selector:@selector(idle)], nil];

        AnimateGroup *walkAnimationGroup = [self animateGroupWithActionWord:@"walk" frameCount:6 delay:1.0/12.0];
        self.walkAction = [CCRepeatForever actionWithAction:walkAnimationGroup];
        
        self.walkSpeed = 80 * kPointFactor;
        self.runSpeed = 160 * kPointFactor;
        self.directionX = 1.0;
        self.centerToBottom = 39.0 * kPointFactor;
        self.centerToSides = 29.0 * kPointFactor;
    }
    return self;
}

-(void)setPosition:(CGPoint)position
{
    [super setPosition:position];
    _belt.position = position;
    _smoke.position = position;
}

-(void)setScaleX:(float)scaleX
{
    [super setScaleX:scaleX];
    _belt.scaleX = scaleX;
    _smoke.scaleX = scaleX;
}

-(void)setScaleY:(float)scaleY
{
    [super setScaleY:scaleY];
    _belt.scaleY = scaleY;
    _smoke.scaleY = scaleY;
}

-(void)setScale:(float)scale
{
    [super setScale:scale];
    _belt.scale = scale;
    _smoke.scale = scale;
}

-(void)setVisible:(BOOL)visible
{
    [super setVisible:visible];
    _belt.visible = visible;
    _smoke.visible = visible;
}

-(void)setColorSet:(ColorSet)colorSet
{
    _colorSet = colorSet;
    if (colorSet == kColorLess)
    {
        self.color = ccWHITE;
        _belt.color = ccWHITE;
        _smoke.color = ccWHITE;
    }
    if (colorSet == kColorCopper)
    {
        self.color = ccc3(255, 193, 158);
        _belt.color = ccc3(99, 162, 255);
        _smoke.color = ccc3(220, 219, 182);
    }
    else if (colorSet == kColorSilver)
    {
        self.color = ccWHITE;
        _belt.color = ccc3(99, 255, 128);
        _smoke.color = ccc3(128, 128, 128);
    }
    else if (colorSet == kColorGold)
    {
        self.color = ccc3(233, 177, 0);
        _belt.color = ccc3(109, 40, 25);
        _smoke.color = ccc3(222, 129, 82);
    }
    else if (colorSet == kColorRandom)
    {
        self.color = ccc3(random_range(0, 255), random_range(0, 255), random_range(0, 255));
        _belt.color = ccc3(random_range(0, 255), random_range(0, 255), random_range(0, 255));
        _smoke.color = ccc3(random_range(0, 255), random_range(0, 255), random_range(0, 255));
    }
}

-(AnimateGroup *)animateGroupWithActionWord:(NSString *)actionKeyWord frameCount:(NSUInteger)frameCount delay:(float)delay
{
    CCAnimation *baseAnimation = [self animationWithPrefix:[NSString stringWithFormat:@"robot_base_%@", actionKeyWord] startFrameIdx:0 frameCount:frameCount delay:delay];
    
    AnimationMember *beltMember = [self animationMemberWithPrefix:[NSString stringWithFormat:@"robot_belt_%@", actionKeyWord] startFrameIdx:0 frameCount:frameCount delay:delay target:_belt];
    
    AnimationMember *smokeMember = [self animationMemberWithPrefix:[NSString stringWithFormat:@"robot_smoke_%@", actionKeyWord] startFrameIdx:0 frameCount:frameCount delay:delay target:_smoke];
    
    CCArray *animationMembers = [CCArray arrayWithNSArray:@[beltMember, smokeMember]];
    
    return [AnimateGroup actionWithAnimation:baseAnimation members:animationMembers];
}

@end
