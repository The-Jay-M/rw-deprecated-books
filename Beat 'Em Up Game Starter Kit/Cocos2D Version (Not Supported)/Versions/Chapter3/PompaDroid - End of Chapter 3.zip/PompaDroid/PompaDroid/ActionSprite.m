//
//  ActionSprite.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "ActionSprite.h"

@implementation ActionSprite

-(void)idle
{
    if (_actionState != kActionStateIdle)
    {
        [self stopAllActions];
        [self runAction:_idleAction];
        _velocity = CGPointZero;
        self.actionState = kActionStateIdle;
    }
}

-(CCAnimation *)animationWithPrefix:(NSString *)prefix startFrameIdx:(NSUInteger)startFrameIdx frameCount:(NSUInteger)frameCount delay:(float)delay
{
    int idxCount = frameCount + startFrameIdx;
    CCArray *frames = [CCArray arrayWithCapacity:frameCount];
    int i;
    CCSpriteFrame *frame;
    for (i = startFrameIdx; i < idxCount; i++)
    {
        frame = [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:[NSString stringWithFormat:@"%@_%02d.png", prefix, i]];
        [frames addObject:frame];
    }
    
    return [CCAnimation animationWithSpriteFrames:[frames getNSArray] delay:delay];
}

-(void)walkWithDirection:(CGPoint)direction
{
    if (_actionState == kActionStateIdle || _actionState == kActionStateRun)
    {
        [self stopAllActions];
        [self runAction:_walkAction];
        self.actionState = kActionStateWalk;
        [self moveWithDirection:direction];
    }
    else if (_actionState == kActionStateWalk)
    {
        [self moveWithDirection:direction];
    }
}

-(void)moveWithDirection:(CGPoint)direction
{
    if (_actionState == kActionStateWalk)
    {
        _velocity = ccp(direction.x * _walkSpeed, direction.y * _walkSpeed);
        [self flipSpriteForVelocity:_velocity];
    }
    else if (_actionState == kActionStateRun)
    {
        _velocity = ccp(direction.x * _runSpeed, direction.y * _walkSpeed);
        [self flipSpriteForVelocity:_velocity];
    }
    else if (_actionState == kActionStateIdle)
    {
        [self walkWithDirection:direction];
    }
}

// Add this new method
-(void)runWithDirection:(CGPoint)direction
{
    if (_actionState == kActionStateIdle || _actionState == kActionStateWalk)
    {
        [self stopAllActions];
        [self runAction:_runAction];
        self.actionState = kActionStateRun;
        [self moveWithDirection:direction];
    }
}

-(void)flipSpriteForVelocity:(CGPoint)velocity
{
    if (velocity.x > 0)
    {
        self.directionX = 1.0;
    }
    else if (velocity.x < 0)
    {
        self.directionX = -1.0;
    }
    
    self.scaleX = _directionX * kScaleFactor;
}

-(void)update:(ccTime)delta
{
    if (_actionState == kActionStateWalk || _actionState == kActionStateRun)
    {
        _desiredPosition = ccpAdd(_groundPosition, ccpMult(_velocity, delta));
    }
    else if (_actionState == kActionStateJumpRise)
    {
        _desiredPosition = ccpAdd(_groundPosition, ccpMult(_velocity, delta));
        _jumpVelocity -= kGravity * delta;
        _jumpHeight += _jumpVelocity * delta;
        
        if (_jumpVelocity <= kJumpForce/2)
        {
            [self jumpFall];
        }
    }
    else if (_actionState == kActionStateJumpFall)
    {
        _desiredPosition = ccpAdd(_groundPosition, ccpMult(_velocity, delta));
        _jumpVelocity -= kGravity * delta;
        _jumpHeight += _jumpVelocity * delta;
        
        if (_jumpHeight <= 0)
        {
            [self jumpLand];
        }
    }
}

-(CGRect)feetCollisionRect
{
    CGRect feetRect = CGRectMake(_desiredPosition.x -_centerToSides, _desiredPosition.y - _centerToBottom, _centerToSides * 2, 5.0 * kPointFactor);
    return CGRectInset(feetRect, 15.0 * kPointFactor, 0);
}

-(void)attack
{
    if (_actionState == kActionStateIdle || _actionState == kActionStateWalk || _actionState == kActionStateAttack)
    {
        [self stopAllActions];
        [self runAction:_attackAction];
        self.actionState = kActionStateAttack;
    }
}

-(void)setGroundPosition:(CGPoint)groundPosition
{
    _groundPosition = groundPosition;
    _shadow.position = ccp(groundPosition.x, groundPosition.y - _centerToBottom);
}

-(void)jumpRiseWithDirection:(CGPoint)direction
{
    if (_actionState == kActionStateIdle)
    {
        [self jumpRise];
    }
    else if (_actionState == kActionStateWalk || _actionState == kActionStateJumpLand)
    {
        _velocity = ccp(direction.x * _walkSpeed, direction.y * _walkSpeed);
        [self flipSpriteForVelocity:_velocity];
        [self jumpRise];
    }
    else if (_actionState == kActionStateRun)
    {
        _velocity = ccp(direction.x * _runSpeed, direction.y * _walkSpeed);
        [self flipSpriteForVelocity:_velocity];
        [self jumpRise];
    }
}

-(void)jumpRise
{
    if (_actionState == kActionStateIdle || _actionState == kActionStateWalk || _actionState == kActionStateRun || _actionState == kActionStateJumpLand)
    {
        [self stopAllActions];
        [self runAction:_jumpRiseAction];
        _jumpVelocity = kJumpForce;
        self.actionState = kActionStateJumpRise;
    }
}


-(void)jumpCutoff
{
    if (_actionState == kActionStateJumpRise)
    {
        if (_jumpVelocity > kJumpCutoff)
        {
            _jumpVelocity = kJumpCutoff;
        }
    }
}

-(void)jumpFall
{
    if (_actionState == kActionStateJumpRise || _actionState == kActionStateJumpAttack)
    {
        self.actionState = kActionStateJumpFall;
        [self runAction:_jumpFallAction];
    }
}

-(void)jumpLand
{
    if (_actionState == kActionStateJumpFall || _actionState == kActionStateRecover)
    {
        _jumpHeight = 0;
        _jumpVelocity = 0;
        self.actionState = kActionStateJumpLand;
        [self runAction:_jumpLandAction];
    }
}

-(AnimationMember *)animationMemberWithPrefix:(NSString *)prefix startFrameIdx:(NSUInteger)startFrameIdx frameCount:(NSUInteger)frameCount delay:(float)delay target:(id)target
{
    CCAnimation *animation = [self animationWithPrefix:prefix startFrameIdx:startFrameIdx frameCount:frameCount delay:delay];
    return [AnimationMember memberWithAnimation:animation target:target];
}

@end
