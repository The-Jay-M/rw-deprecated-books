//
//  GameLayer.h
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Hero.h"
#import "HudLayer.h"

@interface GameLayer : CCLayer <ActionDPadDelegate, ActionButtonDelegate> {
    CCTMXTiledMap *_tileMap;
    CCSpriteBatchNode *_actors;
    float _runDelay;
    ActionDPadDirection _previousDirection;
}

@property(nonatomic, strong)Hero *hero;
@property(nonatomic, weak)HudLayer *hud;
@property(nonatomic, strong)CCArray *robots;

@end
