//
//  HudLayer.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "HudLayer.h"

@implementation HudLayer

-(id)init
{
    if ((self = [super init]))
    {
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"joypad.plist"];
        
        float radius = 64.0 * kPointFactor;
        _dPad = [ActionDPad dPadWithPrefix:@"dpad" radius:radius];
        _dPad.position = ccp(radius, radius);
        _dPad.opacity = 128;
        [self addChild:_dPad];
        
        float buttonRadius = radius / 2.0;
        float padding = 8.0 * kPointFactor;

        _buttonB = [ActionButton buttonWithPrefix:@"button_b" radius:buttonRadius];
        _buttonB.position = ccp(SCREEN.width - buttonRadius - padding, buttonRadius * 2 + padding   );
        _buttonB.opacity = 128;
        _buttonB.tag = kTagButtonB;
        [self addChild:_buttonB];

        _buttonA = [ActionButton buttonWithPrefix:@"button_a" radius:buttonRadius];
        _buttonA.position = ccp(_buttonB.position.x - radius - padding, buttonRadius + padding);
        _buttonA.opacity = 128;
        _buttonA.tag = kTagButtonA;
        [self addChild:_buttonA];

    }
    return self;
}

@end
