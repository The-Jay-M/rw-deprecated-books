//
//  Hero.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "Hero.h"

@implementation Hero

-(id)init {
    if ((self = [super initWithSpriteFrameName:@"hero_idle_00.png"])) {
        //idle animation
        CCAnimation *idleAnimation = [self animationWithPrefix:@"hero_idle" startFrameIdx:0 frameCount:6 delay:1.0/12.0];
        self.idleAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:idleAnimation]];
        
        //walk animation
        CCAnimation *walkAnimation = [self animationWithPrefix:@"hero_walk" startFrameIdx:0 frameCount:8 delay:1.0/12.0];
        self.walkAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:walkAnimation]];
        
        // run animation
        CCAnimation *runAnimation = [self animationWithPrefix:@"hero_run" startFrameIdx:0 frameCount:8 delay:1.0/12.0];
        self.runAction = [CCRepeatForever actionWithAction:[CCAnimate actionWithAnimation:runAnimation]];

        // attack animation
        CCAnimation *attackAnimation = [self animationWithPrefix:@"hero_attack_00" startFrameIdx:0 frameCount:3 delay:1.0/15.0];
        self.attackAction = [CCSequence actions:[CCAnimate actionWithAnimation:attackAnimation], [CCCallFunc actionWithTarget:self selector:@selector(idle)], nil];

        // hurt animation
        CCAnimation *hurtAnimation = [self animationWithPrefix:@"hero_hurt" startFrameIdx:0 frameCount:3 delay:1.0/12.0];
        self.hurtAction = [CCSequence actions:[CCAnimate actionWithAnimation:hurtAnimation], [CCCallFunc actionWithTarget:self selector:@selector(idle)], nil];

        //knocked out animation
        CCAnimation *knockedOutAnimation = [self animationWithPrefix:@"hero_knockout" startFrameIdx:0 frameCount:5 delay:1.0/12.0];
        self.knockedOutAction = [CCAnimate actionWithAnimation:knockedOutAnimation];

        //die action
        self.dieAction = [CCBlink actionWithDuration:2.0 blinks:10.0];

        //recover animation
        CCAnimation *recoverAnimation = [self animationWithPrefix:@"hero_getup" startFrameIdx:0 frameCount:6 delay:1.0/12.0];
        self.recoverAction = [CCSequence actions:[CCAnimate actionWithAnimation:recoverAnimation], [CCCallFunc actionWithTarget:self selector:@selector(jumpLand)], nil];

        self.runSpeed = 160 * kPointFactor;
        self.walkSpeed = 80 * kPointFactor;
        self.directionX = 1.0;
        
        self.centerToBottom = 39.0 * kPointFactor;
        self.centerToSides = 29.0 * kPointFactor;
        
        self.shadow = [CCSprite spriteWithSpriteFrameName:@"shadow_character.png"];
        self.shadow.opacity = 190;

        CCArray *jumpRiseFrames = [CCArray arrayWithCapacity:2];
        [jumpRiseFrames addObject:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"hero_jump_05.png"]];
        [jumpRiseFrames addObject:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"hero_jump_00.png"]];
        self.jumpRiseAction = [CCAnimate actionWithAnimation:[CCAnimation animationWithSpriteFrames:[jumpRiseFrames getNSArray] delay:1.0/12.0]];

        self.jumpFallAction = [CCAnimate actionWithAnimation:[self animationWithPrefix:@"hero_jump" startFrameIdx:1 frameCount:4 delay:1.0/12.0]];

        self.jumpLandAction = [CCSequence actions:[CCCallFunc actionWithTarget:self selector:@selector(setLandingDisplayFrame)], [CCDelayTime actionWithDuration:1.0/12.0], [CCCallFunc actionWithTarget:self selector:@selector(idle)], nil];

        self.detectionRadius = 100.0 * kPointFactor;
        self.attackPointCount = 3;
        self.attackPoints = malloc(sizeof(ContactPoint) * self.attackPointCount);
        self.contactPointCount = 4;
        self.contactPoints = malloc(sizeof(ContactPoint) * self.contactPointCount);

        self.maxHitPoints = 200.0;
        self.hitPoints = self.maxHitPoints;
        self.attackDamage = 5.0;
        self.attackForce = 4.0 * kPointFactor;

    }
    return self;
}

-(void)setLandingDisplayFrame
{
    [self setDisplayFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"hero_jump_05.png"]];
}

-(void)setContactPointsForAction:(ActionState)actionState
{
    if (actionState == kActionStateIdle)
    {
        [self modifyContactPointAtIndex:0 offset:ccp(3.0, 23.0) radius:19.0];
        [self modifyContactPointAtIndex:1 offset:ccp(17.0, 10.0) radius:10.0];
        [self modifyContactPointAtIndex:2 offset:CGPointZero radius:19.0];
        [self modifyContactPointAtIndex:3 offset:ccp(0.0, -21.0) radius:20.0];
    }
    else if (actionState == kActionStateWalk)
    {
        [self modifyContactPointAtIndex:0 offset:ccp(8.0, 23.0) radius:19.0];
        [self modifyContactPointAtIndex:1 offset:ccp(12.0, 4.0) radius:4.0];
        [self modifyContactPointAtIndex:2 offset:CGPointZero radius:10.0];
        [self modifyContactPointAtIndex:3 offset:ccp(0.0, -21.0) radius:20.0];
    }
    else if (actionState == kActionStateAttack)
    {
        [self modifyContactPointAtIndex:0 offset:ccp(15.0, 23.0) radius:19.0];
        [self modifyContactPointAtIndex:1 offset:ccp(24.5, 4.0) radius:6.0];
        [self modifyContactPointAtIndex:2 offset:CGPointZero radius:16.0];
        [self modifyContactPointAtIndex:3 offset:ccp(0.0, -21.0) radius:20.0];
        
        [self modifyAttackPointAtIndex:0 offset:ccp(41.0, 3.0) radius:10.0];
        [self modifyAttackPointAtIndex:1 offset:ccp(41.0, 3.0) radius:10.0];
        [self modifyAttackPointAtIndex:2 offset:ccp(41.0, 3.0) radius:10.0];
    }
    else if (actionState == kActionStateAttackTwo)
    {
        [self modifyAttackPointAtIndex:0 offset:ccp(51.6, 2.4) radius:13.0];
        [self modifyAttackPointAtIndex:1 offset:ccp(51.6, 2.4) radius:13.0];
        [self modifyAttackPointAtIndex:2 offset:ccp(51.6, 2.4) radius:13.0];
    }
    else if (actionState == kActionStateAttackThree)
    {
        [self modifyAttackPointAtIndex:0 offset:ccp(61.8, 6.2) radius:22.0];
        [self modifyAttackPointAtIndex:1 offset:ccp(61.8, 6.2) radius:22.0];
        [self modifyAttackPointAtIndex:2 offset:ccp(61.8, 6.2) radius:22.0];
    }
    else if (actionState == kActionStateRunAttack)
    {
        [self modifyAttackPointAtIndex:0 offset:ccp(31.2, -8.8) radius:10.0];
        [self modifyAttackPointAtIndex:1 offset:ccp(31.2, -8.8) radius:10.0];
        [self modifyAttackPointAtIndex:2 offset:ccp(31.2, -8.8) radius:10.0];
    }
    else if (actionState == kActionStateJumpAttack)
    {
        [self modifyAttackPointAtIndex:2 offset:ccp(70.0, -55.0) radius:8.0];
        [self modifyAttackPointAtIndex:1 offset:ccp(55.0, -42.0) radius:12.0];
        [self modifyAttackPointAtIndex:0 offset:ccp(34.0, -25.0) radius:17.0];
    }
}

-(void)setDisplayFrame:(CCSpriteFrame *)newFrame
{
    [super setDisplayFrame:newFrame];
    
    CCSpriteFrame *attackFrame = [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"hero_attack_00_01.png"];
    
    if (newFrame ==  attackFrame)
    {
        [self.delegate actionSpriteDidAttack:self];
    }    
}


@end
