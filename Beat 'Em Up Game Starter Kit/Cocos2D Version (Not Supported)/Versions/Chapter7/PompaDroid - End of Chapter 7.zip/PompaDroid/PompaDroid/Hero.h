//
//  Hero.h
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "ActionSprite.h"

@interface Hero : ActionSprite {
    float _hurtTolerance;
    float _recoveryRate;
    float _hurtLimit;
    float _attackTwoDelayTime;
    float _attackThreeDelayTime;
    float _chainTimer;
}

@property(nonatomic, strong)id attackTwoAction;
@property(nonatomic, strong)id attackThreeAction;
@property(nonatomic, assign)float attackTwoDamage;
@property(nonatomic, assign)float attackThreeDamage;

@end
