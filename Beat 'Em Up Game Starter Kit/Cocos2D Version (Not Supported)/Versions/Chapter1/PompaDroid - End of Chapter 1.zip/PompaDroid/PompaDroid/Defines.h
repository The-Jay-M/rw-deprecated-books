//
//  Defines.h
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright (c) 2013 Razeware LLC. All rights reserved.
//

#ifndef PompaDroid_Defines_h
#define PompaDroid_Defines_h

#define SCREEN [[CCDirector sharedDirector] winSize]
#define CENTER ccp(SCREEN.width/2, SCREEN.height/2)
#define OFFSCREEN ccp(-SCREEN.width, -SCREEN.height)
#define IS_RETINA() ([[UIScreen mainScreen] respondsToSelector:@selector(scale)] && [[UIScreen mainScreen] scale] == 2)
#define IS_IPHONE5() ([[CCDirector sharedDirector] winSize].width == 568)
#define IS_IPAD() ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
#define CURTIME CACurrentMediaTime()
#define kPointFactor (IS_IPAD() ? 2.0 : 1.0)
#define kScaleFactor (kPointFactor * (IS_RETINA() ? 2.0 : 1.0))

#endif
