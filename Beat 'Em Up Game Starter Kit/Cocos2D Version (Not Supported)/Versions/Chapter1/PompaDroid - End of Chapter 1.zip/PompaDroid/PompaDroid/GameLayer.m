//
//  GameLayer.m
//  PompaDroid
//
//  Created by Ray Wenderlich on 2/8/13.
//  Copyright 2013 Razeware LLC. All rights reserved.
//

#import "GameLayer.h"

@implementation GameLayer

-(id)init
{
    if ((self = [super init]))
    {
        [self initTileMap:@"map_level1.tmx"];
    }
    return self;
}

-(void)initTileMap:(NSString *)fileName
{
    _tileMap = [CCTMXTiledMap tiledMapWithTMXFile:fileName];
    
    for (CCTMXLayer *child in [_tileMap children]) {
        [[child texture] setAliasTexParameters];
	}
    
    _tileMap.scale *= kScaleFactor;
    
    [self addChild:_tileMap z:-6];
}

@end
