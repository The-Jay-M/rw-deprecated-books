//
//  main.m
//  PompaDroid
//
//  Created by Allen Benson G Tan on 11/24/13.
//  Copyright (c) 2013 White Widget Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
