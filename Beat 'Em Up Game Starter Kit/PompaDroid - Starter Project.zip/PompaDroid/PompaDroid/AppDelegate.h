//
//  AppDelegate.h
//  PompaDroid
//
//  Created by Allen Benson G Tan on 11/24/13.
//  Copyright (c) 2013 White Widget Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
