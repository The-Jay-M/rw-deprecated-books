//
//  HudLayer.h
//  PompaDroid
//
//  Created by Allen Tan on 6/10/14.
//
//

#import <SpriteKit/SpriteKit.h>
#import "ActionDPad.h"

@interface HudLayer : SKNode

@property (strong, nonatomic) ActionDPad *dPad;
- (void)update:(NSTimeInterval)delta;

@end
