//
//  HudLayer.m
//  PompaDroid
//
//  Created by Allen Tan on 6/10/14.
//
//

#import "HudLayer.h"

@implementation HudLayer

- (instancetype)init
{
    if (self = [super init])
    {
        //directional pad
        CGFloat radius = 64.0 * kPointFactor;
        _dPad = [ActionDPad dPadWithPrefix:@"dpad" radius:radius];
        _dPad.position = CGPointMake(radius, radius);
        _dPad.alpha = 0.5;
        [self addChild:_dPad];
    }
    
    return self;
}

- (void)update:(NSTimeInterval)delta
{
    [self.dPad update:delta];
}

@end
