//
//  GameLayer.h
//  PompaDroid
//
//  Created by Allen Tan on 6/10/14.
//
//

#import <SpriteKit/SpriteKit.h>
#import "JSTileMap.h"
#import "Hero.h"
#import "HudLayer.h"

@interface GameLayer : SKNode <ActionDPadDelegate, ActionButtonDelegate, ActionSpriteDelegate>

@property (strong, nonatomic) JSTileMap *tileMap;
@property (strong, nonatomic) Hero *hero;
@property (weak, nonatomic) HudLayer *hud;
@property (strong, nonatomic) NSMutableArray *robots;
@property (strong, nonatomic) NSMutableArray *brains;
@property (strong, nonatomic) NSMutableArray *battleEvents;
@property (strong, nonatomic) NSDictionary *currentEvent;
@property (assign, nonatomic) EventState eventState;

- (void)update:(NSTimeInterval)delta;
- (void)startGame;

@end
