//
//  Hero.m
//  PompaDroid
//
//  Created by Allen Tan on 6/11/14.
//
//

#import "Hero.h"
#import "SKTTextureCache.h"
#import "SKAction+SKTExtras.h"

@implementation Hero

- (instancetype)init
{
    SKTTextureCache *cache = [SKTTextureCache sharedInstance];
    SKTexture *texture = [cache textureNamed:@"hero_idle_00"];
    
    self = [super initWithTexture:texture];
    
    if (self)
    {
        NSMutableArray *textures =
        [self texturesWithPrefix:@"hero_idle"
                   startFrameIdx:0 frameCount:6];
        
        SKAction *idleAnimation =
        [SKAction animateWithTextures:textures
                         timePerFrame:1.0/12.0];
        
        self.idleAction =
        [SKAction repeatActionForever:idleAnimation];
        
        textures =
        [self texturesWithPrefix:@"hero_walk"
                   startFrameIdx:0 frameCount:8];
        
        SKAction *walkAnimation =
        [SKAction animateWithTextures:textures
                         timePerFrame:1.0/12.0];
        
        self.walkAction =
        [SKAction repeatActionForever:walkAnimation];
        
        self.walkSpeed = 80 * kPointFactor;
        self.directionX = 1.0;
        
        self.centerToBottom = 39.0 * kPointFactor;
        self.centerToSides = 29.0 * kPointFactor;
        
        textures = [self texturesWithPrefix:@"hero_run"
                              startFrameIdx:0 frameCount:8];

        SKAction *runAnimation =
        [SKAction animateWithTextures:textures timePerFrame:1.0/12.0];
        
        self.runAction = [SKAction repeatActionForever:runAnimation];
        
        self.runSpeed = 160 * kPointFactor;
        
        textures = [self texturesWithPrefix:@"hero_attack_00"
                              startFrameIdx:0
                                 frameCount:3];
        
        SKAction *attackAnimation =
        [self animateActionForTextures:textures
                          timePerFrame:1.0/15.0];
        
        self.attackAction =
        [SKAction sequence:@[attackAnimation, [SKAction performSelector:@selector(idle) onTarget:self]]];
        
        self.shadow = [SKSpriteNode spriteNodeWithTexture:[[SKTTextureCache sharedInstance] textureNamed:@"shadow_character"]];
        self.shadow.alpha = 0.75;
        
        //jump animation
        NSArray *jumpRiseFrames = @[[[SKTTextureCache sharedInstance] textureNamed:@"hero_jump_05"], [[SKTTextureCache sharedInstance]  textureNamed:@"hero_jump_00"]];
        self.jumpRiseAction = [SKAction animateWithTextures:jumpRiseFrames timePerFrame:1.0/12.0];
        
        //fall animation
        self.jumpFallAction = [SKAction animateWithTextures:[self texturesWithPrefix:@"hero_jump" startFrameIdx:1 frameCount:4] timePerFrame:1.0/12.0];
        
        //land animation
        self.jumpLandAction = [SKAction sequence:@[[SKAction setTexture:[[SKTTextureCache sharedInstance] textureNamed:@"hero_jump_05"]], [SKAction waitForDuration:1.0/12.0], [SKAction performSelector:@selector(idle) onTarget:self]]];
        
        //hurt animation
        self.hurtAction = [SKAction sequence:@[[SKAction animateWithTextures:[self texturesWithPrefix:@"hero_hurt" startFrameIdx:0 frameCount:3] timePerFrame:1.0/12.0], [SKAction performSelector:@selector(idle) onTarget:self]]];
        
        //knocked out animation
        self.knockedOutAction = [SKAction animateWithTextures:[self texturesWithPrefix:@"hero_knockout" startFrameIdx:0 frameCount:5] timePerFrame:1.0/12.0];
        self.detectionRadius = 100.0 * kPointFactor;
        
        //die action
        self.dieAction = [SKAction blinkWithDuration:2.0 blinks:10.0];
        
        //recover animation
        self.recoverAction = [SKAction sequence:@[[SKAction animateWithTextures:[self texturesWithPrefix:@"hero_getup" startFrameIdx:0 frameCount:6] timePerFrame:1.0/12.0], [SKAction performSelector:@selector(jumpLand) onTarget:self]]];
        
        self.attackPoints = [self contactPointArray:3];
        self.contactPoints = [self contactPointArray:4];
        
        self.maxHitPoints = 200.0;
        self.hitPoints = self.maxHitPoints;
        self.attackDamage = 5.0;
        self.attackForce = 4.0 * kPointFactor;

    }
    
    return self;
}

- (void)setContactPointsForAction:(ActionState)actionState
{
    if (actionState == kActionStateIdle) {
        
        [self modifyContactPointAtIndex:0
                                 offset:CGPointMake(3.0, 23.0)
                                 radius:19.0];
        
        [self modifyContactPointAtIndex:1
                                 offset:CGPointMake(17.0, 10.0)
                                 radius:10.0];
        
        [self modifyContactPointAtIndex:2
                                 offset:CGPointZero
                                 radius:19.0];
        
        [self modifyContactPointAtIndex:3
                                 offset:CGPointMake(0.0, -21.0)
                                 radius:20.0];
        
    } else if (actionState == kActionStateWalk) {
        
        [self modifyContactPointAtIndex:0
                                 offset:CGPointMake(8.0, 23.0)
                                 radius:19.0];
        
        [self modifyContactPointAtIndex:1
                                 offset:CGPointMake(12.0, 4.0)
                                 radius:4.0];
        
        [self modifyContactPointAtIndex:2
                                 offset:CGPointZero
                                 radius:10.0];
        
        [self modifyContactPointAtIndex:3
                                 offset:CGPointMake(0.0, -21.0)
                                 radius:20.0];
        
    } else if (actionState == kActionStateAttack) {
        
        [self modifyContactPointAtIndex:0
                                 offset:CGPointMake(15.0, 23.0)
                                 radius:19.0];
        
        [self modifyContactPointAtIndex:1
                                 offset:CGPointMake(24.5, 4.0)
                                 radius:6.0];
        
        [self modifyContactPointAtIndex:2
                                 offset:CGPointZero
                                 radius:16.0];
        
        [self modifyContactPointAtIndex:3
                                 offset:CGPointMake(0.0, -21.0)
                                 radius:20.0];
        
        [self modifyAttackPointAtIndex:0
                                offset:CGPointMake(41.0, 3.0)
                                radius:10.0];
        
        [self modifyAttackPointAtIndex:1
                                offset:CGPointMake(41.0, 3.0)
                                radius:10.0];
        
        [self modifyAttackPointAtIndex:2
                                offset:CGPointMake(41.0, 3.0)
                                radius:10.0];
        
    } else if (actionState == kActionStateAttackTwo) {
        
        [self modifyAttackPointAtIndex:0
                                offset:CGPointMake(51.6, 2.4)
                                radius:13.0];
        
        [self modifyAttackPointAtIndex:1
                                offset:CGPointMake(51.6, 2.4)
                                radius:13.0];
        
        [self modifyAttackPointAtIndex:2
                                offset:CGPointMake(51.6, 2.4)
                                radius:13.0];
        
    } else if (actionState == kActionStateAttackThree) {
        
        [self modifyAttackPointAtIndex:0
                                offset:CGPointMake(61.8, 6.2)
                                radius:22.0];
        
        [self modifyAttackPointAtIndex:1
                                offset:CGPointMake(61.8, 6.2)
                                radius:22.0];
        
        [self modifyAttackPointAtIndex:2
                                offset:CGPointMake(61.8, 6.2)
                                radius:22.0];
        
    } else if (actionState == kActionStateRunAttack) {
        
        [self modifyAttackPointAtIndex:0
                                offset:CGPointMake(31.2, -8.8)
                                radius:10.0];
        
        [self modifyAttackPointAtIndex:1
                                offset:CGPointMake(31.2, -8.8)
                                radius:10.0];
        
        [self modifyAttackPointAtIndex:2
                                offset:CGPointMake(31.2, -8.8)
                                radius:10.0];
        
    } else if (actionState == kActionStateJumpAttack) {
        
        [self modifyAttackPointAtIndex:2
                                offset:CGPointMake(70.0, -55.0)
                                radius:8.0];
        
        [self modifyAttackPointAtIndex:1
                                offset:CGPointMake(55.0, -42.0)
                                radius:12.0];
        
        [self modifyAttackPointAtIndex:0
                                offset:CGPointMake(34.0, -25.0)
                                radius:17.0];
    }
}

- (void)setTexture:(SKTexture *)texture
{
    [super setTexture:texture];
    
    SKTexture *attackTexture =
    [[SKTTextureCache sharedInstance]
     textureNamed:@"hero_attack_00_01"];
    
    if (texture == attackTexture) {
        [self.delegate actionSpriteDidAttack:self];
    }
}

@end
