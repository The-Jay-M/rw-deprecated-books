//
//  Boss.h
//  PompaDroid
//
//  Created by Allen Tan on 6/11/14.
//
//

#import "ActionSprite.h"

@interface Boss : ActionSprite

@end
