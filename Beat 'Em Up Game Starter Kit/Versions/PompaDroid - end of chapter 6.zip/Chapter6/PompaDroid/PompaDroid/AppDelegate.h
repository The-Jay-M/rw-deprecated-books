//
//  AppDelegate.h
//  PompaDroid
//
//  Created by Allen Tan on 6/9/14.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
