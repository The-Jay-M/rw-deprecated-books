//
//  Hero.h
//  PompaDroid
//
//  Created by Allen Tan on 6/11/14.
//
//

#import "ActionSprite.h"

@interface Hero : ActionSprite

@property (strong, nonatomic) SKAction *attackTwoAction;
@property (strong, nonatomic) SKAction *attackThreeAction;
@property (assign, nonatomic) CGFloat attackTwoDamage;
@property (assign, nonatomic) CGFloat attackThreeDamage;

@end
