//
//  GameScene.m
//  PompaDroid
//
//  Created by Allen Tan on 6/10/14.
//
//

#import "GameScene.h"
#import "GameLayer.h"
#import "HudLayer.h"
#import "SKTTextureCache.h"

@interface GameScene()

@property (strong, nonatomic) GameLayer *gameLayer;
@property (strong, nonatomic) HudLayer *hudLayer;
@property (assign, nonatomic) NSTimeInterval lastUpdateTime;

@end

@implementation GameScene

- (instancetype)initWithSize:(CGSize)size
{
    if (self = [super initWithSize:size])
    {
        SKTextureAtlas *atlas =
        [SKTextureAtlas atlasNamed:@"sprites"];
        
        [[SKTTextureCache sharedInstance]
         addTexturesFromAtlas:atlas
         filteringMode:SKTextureFilteringNearest];
        
        [[SKTTextureCache sharedInstance]
         setEnableFallbackSuffixes:YES];
        
        atlas = [SKTextureAtlas atlasNamed:@"joypad"];
        
        [[SKTTextureCache sharedInstance]
         addTexturesFromAtlas:atlas
         filteringMode:SKTextureFilteringLinear];
        
        _gameLayer = [GameLayer node];
        [self addChild:_gameLayer];
        
        _hudLayer = [HudLayer node];
        _hudLayer.zPosition = _gameLayer.zPosition + SCREEN.height;
        [self addChild:_hudLayer];
        
        _hudLayer.dPad.delegate = _gameLayer;
        _gameLayer.hud = _hudLayer;
        
        _hudLayer.buttonA.delegate = _gameLayer;
        _hudLayer.buttonB.delegate = _gameLayer;

    }
    return self;
}

- (void)update:(NSTimeInterval)currentTime
{
    if (self.lastUpdateTime <= 0) {
        self.lastUpdateTime = currentTime;
    }
    
    NSTimeInterval delta = currentTime - self.lastUpdateTime;
    self.lastUpdateTime = currentTime;
    
    [self.gameLayer update:delta];
    [self.hudLayer update:delta];
}


@end
