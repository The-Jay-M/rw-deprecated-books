//
//  Robot.m
//  PompaDroid
//
//  Created by Allen Tan on 6/11/14.
//
//

#import "Robot.h"
#import "SKTTextureCache.h"
#import "AnimationMember.h"

@implementation Robot

- (instancetype)init
{
    
    SKTTextureCache *cache = [SKTTextureCache sharedInstance];
    NSString *textureName = @"robot_base_idle_00";
    SKTexture *texture = [cache textureNamed:textureName];
    
    self = [super initWithTexture:texture];
    
    if (self) {
        
        SKTexture *beltTeture =
        [cache textureNamed:@"robot_belt_idle_00"];
        self.belt =
        [SKSpriteNode spriteNodeWithTexture:beltTeture];
        
        SKTexture *smokeTexture =
        [cache textureNamed:@"robot_smoke_idle_00"];
        self.smoke =
        [SKSpriteNode spriteNodeWithTexture:smokeTexture];
        
        SKTexture *shadowTexture =
        [cache textureNamed:@"shadow_character"];
        self.shadow =
        [SKSpriteNode spriteNodeWithTexture:shadowTexture];
        
        self.shadow.alpha = 0.75;
        
        //idle animation
        SKAction *idleAnimationGroup =
        [self animateActionForActionWord:@"idle"
                            timePerFrame:1.0/12.0
                              frameCount:5];
        self.idleAction =
        [SKAction repeatActionForever:idleAnimationGroup];
        
        //attack animation
        SKAction *attackAnimationGroup =
        [self animateActionForActionWord:@"attack"
                            timePerFrame:1.0/15.0
                              frameCount:5];
        
        self.attackAction =
        [SKAction sequence:@[attackAnimationGroup, [SKAction performSelector:@selector(idle) onTarget:self]]];
        
        //walk animation
        SKAction *walkAnimationGroup =
        [self animateActionForActionWord:@"walk"
                            timePerFrame:1.0/12.0
                              frameCount:6];
        
        self.walkAction =
        [SKAction repeatActionForever:walkAnimationGroup];
        
        self.walkSpeed = 80 * kPointFactor;
        self.runSpeed = 160 * kPointFactor;
        self.directionX = 1.0;
        self.centerToBottom = 39.0 * kPointFactor;
        self.centerToSides = 29.0 * kPointFactor;
        self.colorBlendFactor = 1.0;
        self.belt.colorBlendFactor = 1.0;
        self.smoke.colorBlendFactor = 1.0;
    }
    return self;
}

- (void)setPosition:(CGPoint)position
{
    [super setPosition:position];
    self.belt.position = position;
    self.smoke.position = position;
}

- (void)setXScale:(CGFloat)xScale
{
    [super setXScale:xScale];
    self.belt.xScale = xScale;
    self.smoke.xScale = xScale;
}

- (void)setYScale:(CGFloat)yScale
{
    [super setYScale:yScale];
    self.belt.yScale = yScale;
    self.smoke.yScale = yScale;
}

- (void)setScale:(CGFloat)scale
{
    [super setScale:scale];
    self.belt.scale = scale;
    self.smoke.scale = scale;
}

- (void)setHidden:(BOOL)hidden
{
    [super setHidden:hidden];
    self.belt.hidden = hidden;
    self.smoke.hidden = hidden;
}

- (void)setZPosition:(CGFloat)zPosition
{
    [super setZPosition:zPosition];
    self.smoke.zPosition = zPosition;
    self.belt.zPosition = zPosition;
}
- (SKAction *)animateActionForActionWord:(NSString *)actionKeyWord timePerFrame:(NSTimeInterval)timeInterval frameCount:(NSUInteger)frameCount
{
    AnimationMember *baseAnimation = [AnimationMember animationWithTextures:[self texturesWithPrefix:[NSString stringWithFormat:@"robot_base_%@", actionKeyWord] startFrameIdx:0 frameCount:frameCount] target:self];
    
    AnimationMember *beltAnimation = [AnimationMember animationWithTextures:[self texturesWithPrefix:[NSString stringWithFormat:@"robot_belt_%@", actionKeyWord] startFrameIdx:0 frameCount:frameCount] target:_belt];
    
    AnimationMember *smokeAnimation = [AnimationMember animationWithTextures:[self texturesWithPrefix:[NSString stringWithFormat:@"robot_smoke_%@", actionKeyWord] startFrameIdx:0 frameCount:frameCount] target:_smoke];
    
    NSMutableArray *actionGroup = [@[baseAnimation, beltAnimation, smokeAnimation] mutableCopy];
    
    return [self animateActionForGroup:actionGroup
                          timePerFrame:timeInterval
                            frameCount:frameCount];
}
- (void)setColorSet:(ColorSet)colorSet
{
    _colorSet = colorSet;
    
    if (colorSet == kColorLess) {
        
        self.color = [UIColor whiteColor];
        self.belt.color = [UIColor whiteColor];
        self.smoke.color = [UIColor whiteColor];
        
    } else if (colorSet == kColorCopper) {
        
        self.color = [UIColor colorWithRed:255/255.0
                                     green:193/255.0
                                      blue:158/255.0
                                     alpha:1.0];
        
        self.belt.color = [UIColor colorWithRed:99/255.0
                                          green:162/255.0
                                           blue:1.0
                                          alpha:1.0];
        
        self.smoke.color = [UIColor colorWithRed:220/255.0
                                           green:219/255.0
                                            blue:182/255.0
                                           alpha:1.0];
        
    } else if (colorSet == kColorSilver) {
        
        self.color = [UIColor whiteColor];
        
        self.belt.color = [UIColor colorWithRed:99/255.0
                                          green:1.0
                                           blue:128/255.0
                                          alpha:1.0];
        
        self.smoke.color = [UIColor colorWithRed:128/255.0
                                           green:128/255.0
                                            blue:128/255.0
                                           alpha:1.0];
        
    } else if (colorSet == kColorGold) {
        
        self.color = [UIColor colorWithRed:233/255.0
                                     green:177/255.0
                                      blue:0
                                     alpha:1.0];
        
        self.belt.color = [UIColor colorWithRed:109/255.0
                                          green:40/255.0
                                           blue:25/255.0
                                          alpha:1.0];
        
        self.smoke.color = [UIColor colorWithRed:222/255.0
                                           green:129/255.0
                                            blue:82/255.0
                                           alpha:1.0];
        
    } else if (colorSet == kColorRandom) {
        
        self.color =
        [UIColor colorWithRed:RandomFloatRange(0, 1)
                        green:RandomFloatRange(0, 1)
                         blue:RandomFloatRange(0, 1)
                        alpha:1.0];
        
        self.belt.color =
        [UIColor colorWithRed:RandomFloatRange(0, 1)
                        green:RandomFloatRange(0, 1)
                         blue:RandomFloatRange(0, 1)
                        alpha:1.0];
        
        self.smoke.color =
        [UIColor colorWithRed:RandomFloatRange(0, 1)
                        green:RandomFloatRange(0, 1)
                         blue:RandomFloatRange(0, 1)
                        alpha:1.0];
    }
}


@end
