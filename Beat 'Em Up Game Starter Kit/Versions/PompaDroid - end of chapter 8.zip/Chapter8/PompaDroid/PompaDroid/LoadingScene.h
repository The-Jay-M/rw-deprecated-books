//
//  LoadingScene.h
//  PompaDroid
//
//  Created by Allen Tan on 6/11/14.
//
//

#import <SpriteKit/SpriteKit.h>

@interface LoadingScene : SKScene

@end
