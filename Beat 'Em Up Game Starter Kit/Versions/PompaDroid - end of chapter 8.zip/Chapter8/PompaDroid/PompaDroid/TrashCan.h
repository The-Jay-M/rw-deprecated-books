//
//  TrashCan.h
//  PompaDroid
//
//  Created by Allen Tan on 6/11/14.
//
//

#import "MapObject.h"

@interface TrashCan : MapObject

@end
