//
//  Gauntlets.h
//  PompaDroid
//
//  Created by Allen Tan on 6/11/14.
//
//

#import "Weapon.h"

@interface Gauntlets : Weapon

@end
