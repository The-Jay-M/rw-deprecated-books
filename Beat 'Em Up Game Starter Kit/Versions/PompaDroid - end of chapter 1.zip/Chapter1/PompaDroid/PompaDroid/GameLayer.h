//
//  GameLayer.h
//  PompaDroid
//
//  Created by Allen Tan on 6/10/14.
//
//

#import <SpriteKit/SpriteKit.h>
#import "JSTileMap.h"

@interface GameLayer : SKNode

@property (strong, nonatomic) JSTileMap *tileMap;

@end
