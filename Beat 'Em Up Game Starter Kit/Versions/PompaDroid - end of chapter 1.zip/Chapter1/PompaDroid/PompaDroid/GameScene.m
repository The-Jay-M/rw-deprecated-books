//
//  GameScene.m
//  PompaDroid
//
//  Created by Allen Tan on 6/10/14.
//
//

#import "GameScene.h"
#import "GameLayer.h"
#import "HudLayer.h"

@implementation GameScene

- (instancetype)initWithSize:(CGSize)size
{
    if (self = [super initWithSize:size])
    {
        GameLayer *gameLayer = [GameLayer node];
        [self addChild:gameLayer];
        
        HudLayer *hudLayer = [HudLayer node];
        [self addChild:hudLayer];
    }
    return self;
}

@end
