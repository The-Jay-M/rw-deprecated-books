//
//  GameLayer.m
//  PompaDroid
//
//  Created by Allen Tan on 6/10/14.
//
//

#import "GameLayer.h"

@implementation GameLayer

- (instancetype)init
{
    if (self = [super init])
    {
        [self initTileMap:@"map_level1.tmx"];
    }
    return self;
}

- (void)initTileMap:(NSString *)fileName
{
    self.tileMap = [JSTileMap mapNamed:fileName];
    [self.tileMap setScale:kPointFactor];
    [self addChild:self.tileMap];
}

@end
