//
//  AlbumPageViewController.h
//  PhotoAlbum
//
//  Created by Felipe on 12/22/13.
//  Copyright (c) 2013 Felipe Laso MArsetti. All rights reserved.
//

@interface AlbumPageViewController : UIViewController

@property (assign, nonatomic) NSUInteger index;
@property (strong, nonatomic) NSArray *picturesArray;

@end
