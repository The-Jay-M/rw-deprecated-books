//
//  RootViewController.h
//  PhotoAlbum
//
//  Created by Felipe on 12/22/13.
//  Copyright (c) 2013 Felipe Laso MArsetti. All rights reserved.
//

@interface RootViewController : UIViewController <UIPageViewControllerDataSource, UIPageViewControllerDelegate>

@property (strong, nonatomic) UIPageViewController *pageViewController;
@property (strong, nonatomic) NSArray *picturesArray;

@end
