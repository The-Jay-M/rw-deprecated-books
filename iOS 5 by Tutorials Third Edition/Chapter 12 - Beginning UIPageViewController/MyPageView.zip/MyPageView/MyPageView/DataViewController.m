//
//  DataViewController.m
//  MyPageView
//
//  Created by Felipe on 12/22/13.
//  Copyright (c) 2013 Felipe. All rights reserved.
//

#import "DataViewController.h"

@implementation DataViewController

#pragma mark - View Controller

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.dataLabel.text = [self.dataObject description];
}

@end
