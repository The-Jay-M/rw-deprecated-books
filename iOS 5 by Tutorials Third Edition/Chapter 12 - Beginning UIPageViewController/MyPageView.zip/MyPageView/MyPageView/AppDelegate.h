//
//  AppDelegate.h
//  MyPageView
//
//  Created by Felipe on 12/22/13.
//  Copyright (c) 2013 Felipe. All rights reserved.
//

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
