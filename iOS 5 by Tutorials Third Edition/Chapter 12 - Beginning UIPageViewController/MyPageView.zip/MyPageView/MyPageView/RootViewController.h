//
//  RootViewController.h
//  MyPageView
//
//  Created by Felipe on 12/22/13.
//  Copyright (c) 2013 Felipe. All rights reserved.
//

@interface RootViewController : UIViewController <UIPageViewControllerDelegate>

@property (strong, nonatomic) UIPageViewController *pageViewController;

@end
