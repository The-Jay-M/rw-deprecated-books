//
//  DataViewController.h
//  MyPageView
//
//  Created by Felipe on 12/22/13.
//  Copyright (c) 2013 Felipe. All rights reserved.
//

@interface DataViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *dataLabel;
@property (strong, nonatomic) id dataObject;

@end
