//
//  ModelController.h
//  MyPageView
//
//  Created by Felipe on 12/22/13.
//  Copyright (c) 2013 Felipe. All rights reserved.
//


@class DataViewController;

@interface ModelController : NSObject <UIPageViewControllerDataSource>

- (NSUInteger)indexOfViewController:(DataViewController *)viewController;
- (DataViewController *)viewControllerAtIndex:(NSUInteger)index storyboard:(UIStoryboard *)storyboard;

@end
