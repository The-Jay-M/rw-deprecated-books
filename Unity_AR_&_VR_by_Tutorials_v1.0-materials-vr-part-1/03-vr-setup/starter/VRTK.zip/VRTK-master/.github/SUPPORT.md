Only submit an issue if you have a known bug or are requesting a new feature.

If you require help or support then ask a question in the official VRTK Slack channel at http://invite.vrtk.io
