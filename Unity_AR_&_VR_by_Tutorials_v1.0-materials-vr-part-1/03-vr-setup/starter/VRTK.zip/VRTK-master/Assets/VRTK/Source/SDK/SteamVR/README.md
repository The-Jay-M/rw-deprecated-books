# SteamVR

## Instructions for using SteamVR

 * Import the [SteamVR Plugin](https://assetstore.unity.com/packages/templates/systems/steamvr-plugin-32647) from the Unity Asset Store.
 * Follow the initial [Getting Started](/Assets/VRTK/Documentation/GETTING_STARTED.md) steps and then add the `[CameraRig]` prefab from the [SteamVR Plugin](https://assetstore.unity.com/packages/templates/systems/steamvr-plugin-32647) as a child of the SDK Setup GameObject.
